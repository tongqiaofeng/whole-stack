const fs = require('fs')

test('集成测试 测试生成测试代码的文件', () => {
  // 测试前的环境准备
  // 删除上一次执行测试后产生的测试目录
  // __dirname => 当前文件的父文件名
  fs.rmdirSync(__dirname + '/data/__test__', {
    recursive: true // 迭代
  })

  const src = new(require('../index'))()
  src.genJestSource(__dirname + '/data')
})



// test('测试测试代码的生成', () => {
//   const src = new(require('../index'))();
//   const ret = src.getTestSource('fun', 'class');
//   console.log('ret: ', ret);
//   expect(ret).toBe(`
//   test('Test fun',() => {
//     const fun = require('../class');
//     const ret = fun();
//     // expect(ret)
//     // .toBe('test return')
//   })
//     `)
// })


// test('测试文件名生成', () => {
//   const src = new(require('../index'))()
//   const ret = src.getTestFileName('/abc/class.js')
//   console.log('getTestFileName:', ret);

//   expect(ret).toBe('/abc/__test__/class.spec.js')
// })