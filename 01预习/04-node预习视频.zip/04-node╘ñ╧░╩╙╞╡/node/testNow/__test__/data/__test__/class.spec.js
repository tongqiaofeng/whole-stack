
  test('Test fun01',() => {
    const {fun01} = require('../class.js');
    const ret = fun01();
    // expect(ret)
    // .toBe('test return')
  })
    

  test('Test fun02',() => {
    const {fun02} = require('../class.js');
    const ret = fun02();
    // expect(ret)
    // .toBe('test return')
  })
    