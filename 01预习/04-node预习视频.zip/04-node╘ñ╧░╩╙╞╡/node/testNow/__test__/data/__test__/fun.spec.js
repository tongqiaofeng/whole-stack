
  test('Test fun',() => {
    const fun = require('../fun.js');
    const ret = fun();
    // expect(ret)
    // .toBe('test return')
  })
    