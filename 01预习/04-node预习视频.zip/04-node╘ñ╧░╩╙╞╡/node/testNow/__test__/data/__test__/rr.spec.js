
  test('Test rr',() => {
    const rr = require('../rr.js');
    const ret = rr();
    // expect(ret)
    // .toBe('test return')
  })
    