module.exports = {
  fun01: () => 'fun01 run',
  fun02: () => 'fun02 run',
}