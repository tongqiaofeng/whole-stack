const path = require('path')
const fs = require('fs')

module.exports = class TestNow {
  //             默认值为当前文件同级的文件
  genJestSource(sourcePath = path.resolve('./')) {
    console.log('sourcePath: ', sourcePath);
    const testPath = `${sourcePath}/__test__`;
    // 如果没有测试文件
    if (!fs.existsSync(testPath)) {
      // 就生成一个
      fs.mkdirSync(testPath)
    }

    // 遍历代码文件
    // 获取data文件夹下的所有文件名称
    let list = fs.readdirSync(sourcePath)
    console.log(list);
    list
      // 添加完整路径
      .map(v => `${sourcePath}/${v}`)
      // 过滤文件  判断一个文件是不是文件或者文件夹
      .filter(v => fs.statSync(v).isFile())
      // 排除测试文件
      .filter(v => v.indexOf('.spec') === -1)
      .map(v => this.genTestFile(v))
  }

  // 生成测试文件
  genTestFile(fileName) {
    console.log('fileName: ', fileName);
    // 测试文件名
    const testFileName = this.getTestFileName(fileName)

    // 判断此文件是否存在
    if (fs.existsSync(testFileName)) {
      console.log('该测试代码已存在', testFileName);
      return
    }

    const mod = require(fileName)
    let source
    if (typeof mod === 'object') {
      source = Object.keys(mod)
        .map(v => this.getTestSource(v, path.basename(fileName), true))
        .join('\n')
    } else if (typeof mod === 'function') {
      const basename = path.basename(fileName)
      source = this.getTestSource(basename.replace('.js', ''), basename)
    }
    fs.writeFileSync(testFileName, source)
  }

  // 测试代码
  getTestSource(methodName, classFile, isClass = false) {
    console.log('getTestSource: ', methodName);
    return `
  test('${'Test ' + methodName}',() => {
    const ${isClass ? '{' + methodName + '}' : methodName} = require('${'../' + classFile}');
    const ret = ${methodName}();
    // expect(ret)
    // .toBe('test return')
  })
    `
  }

  /**
   * JSDoc是一个根据javascript文件中注释信息,生成JavaScript应用程序
   * 或库、模块的API文档 的工具。你可以使用它记录如:命名空间,类,方法,
   * 方法参数等
   * 
   * 生成测试文件名
   * @param {*} fileName  代码文件名
   */
  getTestFileName(fileName) {
    // fileName  /abc/class.js
    const dirName = path.dirname(fileName)
    console.log(dirName); // /abc
    const baseName = path.basename(fileName)
    console.log(baseName); // class.js
    const extName = path.extname(fileName)
    console.log(extName); // .js
    // 将baseName class.js中的.js替换为.spec.js
    const testName = baseName.replace(extName, `.spec${extName}`)
    console.log(testName); // class.spec.js

    return path.format({
      root: dirName + '/__test__/',
      base: testName
    })
  }
}