test('测试helloworld', () => {
  const ret = require('../index')
  // console.log('ret', ret);

  // 断言
  expect(ret).toBe('hello world')
})