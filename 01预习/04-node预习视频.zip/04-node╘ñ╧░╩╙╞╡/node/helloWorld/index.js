// npm i nodemon -g
// 运行nodemon index.js

// npm i jest -g
// 在helloWorld下运行npm init 再 jest helloWorld
// 或 jest helloWorld --watch
const newLocal = 'hello world';
console.log(newLocal);

module.exports = newLocal