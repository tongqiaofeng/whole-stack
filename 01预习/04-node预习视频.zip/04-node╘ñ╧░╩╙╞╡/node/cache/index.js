// http缓存机制
function updateTime() {
  setInterval(() => {
    this.time = new Date().toUTCString()
  }, 1000);

  return this.time
}

const http = require('http')
http.createServer((req, res) => {
  const {
    url
  } = req;

  if (url === '/') {
    res.end(`
      <html>
        Html Update Time ${updateTime()}
        <script src='main.js'></script>
      </html>
    `)
  } else if (url === '/main.js') {
    const content = `document.writeln('<br>JS Update Time: ${updateTime()}')`
    res.setHeader('Expires', new Date(Date.now() + 10 * 1000).toUTCString())

    res.statusCode = 200
    res.end(content)
  } else if (url === '/favicon.con') {
    res.end('')
  }
}).listen(3000, () => {
  console.log('Http Cache Test Run at ' + 3000);
})