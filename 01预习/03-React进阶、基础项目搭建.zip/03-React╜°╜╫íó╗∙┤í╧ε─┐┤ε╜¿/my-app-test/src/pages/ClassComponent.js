// rcc 快速创建一个组件（使用extends方式）
// rconst 快速创建一个constructor
// rcep 快速创建一个组件（使用extends方式）
// rcredux 快速创建一个 redux格式的类模板
import React, { Component } from "react";

export default class ClassComponent extends Component {
  constructor(props) {
    /* 在class方法中，继承是使用extends关键字来实现继承的。
    子类必须在constructor()中调用super()方法，否则新建实例时会报错。
    报错的原因是，子类是没有自己的this对象的，它只能继承父类的this对象，
    然后对其进行加工，而super()就是将父类中的this对象继承给子类的。
    没有super，子类就得不到this对象
    */
    super(props);

    // 初始化数据
    this.state = {
      date: new Date(),
      name: "lucky",
    };
  }

  // 组件挂载完成之后执行
  componentDidMount() {
    this.timer = setInterval(() => {
      // 修改state，不能使用this.state.xxx = xxx
      this.setState({
        date: new Date(),
      });
    }, 1000);
  }

  // 组件卸载之前执行
  componentWillUnmount() {
    clearInterval(this.timer);
  }

  render() {
    const { date, name } = this.state;
    return (
      <div>
        <h3>ClassComponent</h3>
        {/* <p>{this.state.date.toLocaleTimeString()}</p> */}
        <p>{name + " " + date.toLocaleTimeString()}</p>
      </div>
    );
  }
}
