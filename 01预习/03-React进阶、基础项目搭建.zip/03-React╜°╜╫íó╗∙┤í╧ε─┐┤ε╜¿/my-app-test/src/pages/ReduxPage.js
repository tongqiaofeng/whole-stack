import React, { Component } from "react";
import store from "../store/index";

export default class ReduxPage extends Component {
  componentDidMount() {
    // 订阅
    store.subscribe(() => {
      console.log("数据发生变化");
      this.forceUpdate();
    });
  }
  render() {
    console.log(store);
    return (
      <div>
        <h3> ReduxPage </h3> <p> {store.getState()} </p>
        <button onClick={() => store.dispatch({ type: "Add" })}>吼哈</button>
        <button
          onClick={() =>
            store.dispatch({
              type: "Minus",
            })
          }
        >
          减法
        </button>
      </div>
    );
  }
}
