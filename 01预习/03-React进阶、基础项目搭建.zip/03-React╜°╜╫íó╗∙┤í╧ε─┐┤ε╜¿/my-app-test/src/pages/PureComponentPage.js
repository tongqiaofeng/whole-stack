import React, { Component, PureComponent } from "react";

export default class PureComponentPage extends PureComponent {
  constructor(props) {
    super(props);

    this.state = {
      counter: 0,
    };
  }

  // shouldComponentUpdate(nextProps, nextState) {
  //   return nextState.counter !== this.state.counter;
  // }

  setCounter = () => {
    this.setState({ counter: 100 });
  };

  render() {
    console.log(this.state.counter);
    return (
      <div>
        <h3> PureComponentPage </h3>
        <button onClick={this.setCounter}>{this.state.counter}</button>
      </div>
    );
  }
}
