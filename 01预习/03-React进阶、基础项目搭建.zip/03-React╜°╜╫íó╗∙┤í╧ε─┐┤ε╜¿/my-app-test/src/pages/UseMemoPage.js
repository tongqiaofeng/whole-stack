import React, { useState, useEffect, useMemo } from "react";

export default function UseMemoPage() {
  const [count, setCount] = useState(0);
  const [value, setValue] = useState("");

  const expensive = useMemo(() => {
    console.log("computed");
    let num = 0;
    for (let i = 0; i < count; i++) {
      num += i;
    }
    return num;
  }, [count]);

  return (
    <div>
      <h3>UseMemoPage</h3>
      <p>count: {count}</p>
      <p>expensive: {expensive}</p>
      <button onClick={() => setCount(count + 1)}>add</button>
      <input
        type="text"
        value={value}
        onChange={(e) => {
          setValue(e.target.value);
        }}
      />
    </div>
  );
}
