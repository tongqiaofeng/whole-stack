import React, { Component } from "react";
import TopBar from "../../components/TopBar";
import BottomBar from "../../components/BottomBar";

// composition 组件复合
export default class Layout extends Component {
  componentDidMount() {
    const { title = "商城" } = this.props;
    document.title = title;
  }
  render() {
    const { children, showTopBar, showBottomBar } = this.props;
    console.log(children);
    return (
      <div>
        {" "}
        {showTopBar && <TopBar> </TopBar>} {/* 具名插槽 */} {children.content}{" "}
        {children.text} <button onClick={children.btnClick}> 点 我 </button>{" "}
        {showBottomBar && <BottomBar> </BottomBar>}{" "}
      </div>
    );
  }
}
