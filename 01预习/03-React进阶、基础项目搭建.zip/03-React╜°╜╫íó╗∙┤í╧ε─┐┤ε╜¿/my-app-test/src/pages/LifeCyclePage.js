import React, { Component } from "react";
// import PropTypes from "prop-types";

export default class LifeCyclePage extends Component {
  // static defaultProps = {
  //   msg: "omg",
  // };
  // static propTypes = {
  //   msg: PropTypes.string.isRequired,
  // };

  constructor(props) {
    super(props);
    this.state = {
      count: 0,
    };
    console.log("constructor");
  }

  static getDerivedStateFromProps(props, state) {
    console.log("getDerivedStateFromProps");
    const { count } = state;
    return count > 8 ? { count: 0 } : null;
  }

  // UNSAFE_componentWillMount() {
  //   console.log("componentWillMount");
  // }

  componentDidMount() {
    console.log("componentDidMount");
  }

  shouldComponentUpdate(nextProps, nextState) {
    const { count } = nextState;
    console.log("shouldComponentUpdate", nextState);
    return count !== 5;
  }

  getSnapshotBeforeUpdate(prevProps, prevState) {
    console.log("getSnapshotBeforeUpdate", prevProps, prevState);
    return {
      msg: "我是getSnapshotBeforeUpdate",
    };
  }
  // UNSAFE_componentWillUpdate() {
  //   console.log("componentWillUpdate");
  // }

  setCount = () => {
    console.log("改变");
    this.setState({
      count: this.state.count + 1,
    });
  };

  render() {
    console.log("render", this.props);
    return (
      <div>
        <h3>LifeCyclePage</h3>
        <h3>{this.state.count}</h3>
        <button onClick={this.setCount}>修改</button>
        {/* {this.state.count % 2 && <Child count={this.state.count}></Child>} */}
        <Child count={this.state.count}></Child>
      </div>
    );
  }

  componentDidUpdate(prevProps, prevState, snapshot) {
    console.log("componentDidUpdate", prevProps, prevState, snapshot);
  }
}

class Child extends Component {
  // 初次渲染的时候不会执行，只有在已挂载的组件接收新的props的时候，才会执行
  // UNSAFE_componentWillReceiveProps(nextProps) {
  //   console.log("componentWillReceiveProps", nextProps);
  // }

  componentWillUnmount() {
    console.log("componentWillUnmount");
  }

  render() {
    console.log("Child render");
    return (
      <div>
        <h3>{this.props.count}</h3>
      </div>
    );
  }
}
