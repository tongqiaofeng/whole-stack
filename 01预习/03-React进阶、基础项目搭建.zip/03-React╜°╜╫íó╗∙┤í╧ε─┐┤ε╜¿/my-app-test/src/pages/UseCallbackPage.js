import React, { useState, useEffect, useCallback, PureComponent } from "react";

export default function UseCallbackPage() {
  const [count, setCount] = useState(0);
  const [value, setValue] = useState("");

  const addClick = useCallback(() => {
    let num = 0;
    for (let i = 0; i < count; i++) {
      num += i;
    }
    return num;
  }, [count]);

  return (
    <div>
      <h3>UseCallbackPage</h3>
      <p>count: {count}</p>
      <button onClick={() => setCount(count + 1)}>add</button>
      <input
        type="text"
        value={value}
        onChange={(e) => {
          setValue(e.target.value);
        }}
      />
      <Child addClick={addClick}></Child>
    </div>
  );
}

// PureComponent定制了shouldComponentUpdate后的Component
class Child extends PureComponent {
  render() {
    console.log("render");
    const { addClick } = this.props;
    return (
      <div>
        <h3>Child</h3>
        <button onClick={() => console.log(addClick())}>sss</button>
      </div>
    );
  }
}
