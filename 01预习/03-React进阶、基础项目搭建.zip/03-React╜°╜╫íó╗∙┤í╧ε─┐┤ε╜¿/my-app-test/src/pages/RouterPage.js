import React, { Component } from "react";
import { BrowserRouter as Router, Route, Link, Switch } from "react-router-dom";

export default class RouterPage extends Component {
  render() {
    return (
      <div>
        <h3> RouterPage </h3>
        <Router>
          <Link to="/">首页</Link>
          <Link to="/user">用户中心</Link>

          {/* Switch 表示仅匹配一个 */}
          <Switch>
            {/* exact是Route下的一个属性，react路由会匹配到所有能匹配到的路由组件，
          exact能够使得路由的匹配更严格一些。exact的值为bool型，为true时表示严格匹配，
          为false时为正常匹配。  */}
            <Route
              exact
              path="/"
              // children={() => <div>children</div>}
              // component={HomePage}
              render={() => <div>render</div>}
            ></Route>
            <Route path="/user" component={UserPage}></Route>
            <Route component={EmptyPage}></Route>
          </Switch>
        </Router>
      </div>
    );
  }
}

class HomePage extends Component {
  render() {
    return (
      <div>
        <h3>HomePage</h3>
      </div>
    );
  }
}

class UserPage extends Component {
  render() {
    return (
      <div>
        <h3>UserPage</h3>
      </div>
    );
  }
}

class EmptyPage extends Component {
  render() {
    return (
      <div>
        <h3>EmptyPage-404</h3>
      </div>
    );
  }
}
