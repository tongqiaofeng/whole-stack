// rfc 快速生成function组件
// function组件默认无状态
import React, { useState, useEffect } from "react";

export default function FunctionComponent() {
  const [date, setDate] = useState(new Date());
  const [name] = useState("lucky");
  useEffect(() => {
    // 相当于componentDidMount、componentDidUpdate、componentWillUnmount 的集合
    const timer = setInterval(() => {
      setDate(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []); // 依赖项，该值发生改变才会执行上述操作
  return (
    <div>
      <h3> FunctionComponent </h3>
      <p> {name + " " + date.toLocaleTimeString()} </p>
    </div>
  );
}
