import React from "react";
import UseCallbackPage from "./pages/UseCallbackPage";
// import logo from "./logo.svg";
// import "./App.css";
// import ClassComponent from "./pages/ClassComponent";
// import FunctionComponent from "./pages/FunctionComponent";
// import SetStatePage from "./pages/SetStatePage";
// import HomePage from "./pages/composition/HomePage";
// import UserPage from "./pages/composition/UserPage";
// import ReduxPage from "./pages/ReduxPage";
// import RouterPage from "./pages/RouterPage";
// import PureComponentPage from "./pages/PureComponentPage";
// import LifeCyclePage from "./pages/LifeCyclePage";
// import { Button } from "antd";
// import "antd/dist/antd.css";
// import HookPage from "./pages/HookPage";
// import UseMemoPage from "./pages/UseMemoPage";

function App() {
  return (
    <div className="App">
      {/* <ClassComponent></ClassComponent> */}
      {/* <FunctionComponent></FunctionComponent> */}
      {/* <SetStatePage></SetStatePage> */} {/* <HomePage></HomePage> */}
      {/* <UserPage></UserPage> */} {/* <ReduxPage></ReduxPage> */}
      {/* <RouterPage> </RouterPage> */}
      {/* <PureComponentPage></PureComponentPage> */}
      {/* <LifeCyclePage></LifeCyclePage> */}
      {/* <Button type="primary">222</Button> */}
      {/* <HookPage></HookPage> */}
      {/* <UseMemoPage></UseMemoPage> */}
      <UseCallbackPage></UseCallbackPage>
    </div>
  );
}

export default App;
