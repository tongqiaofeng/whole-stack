import React, { Component } from "react";

export default class BottomBar extends Component {
  render() {
    return (
      <div className="bottomBar">
        <h3> BottomBar </h3>
      </div>
    );
  }
}
