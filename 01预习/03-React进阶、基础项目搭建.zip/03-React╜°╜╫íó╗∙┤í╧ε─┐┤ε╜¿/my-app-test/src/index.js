// React负责逻辑控制，数据 -> VDOM
import React from "react";
// ReactDOM渲染实际DOM，VDOM -> DOM
import ReactDOM from "react-dom";
import "./index.css";
import App from "./App";
import * as serviceWorker from "./serviceWorker";
// 样式模块化 避免不同组件间相同class名影响
// import styles from "./index.module.css";
// import logo from "./logo.svg";
// import store from "./store/index";

// const name = "未来";
// const obj = {
//   name: "john",
//   age: 18,
// };
// const list = [1, 2, 3];
// // JSX对象
// const greet = <div>欧耶</div>;
// const show = false;
// const jsx = (
//   <div>
//     <div> hello,{name} </div>
//     <div>{obj.name + " " + obj.age}</div>
//     {greet}
//     {show ? greet : "啦啦啦"}
//     {show && greet}
//     <ul>
//       {/* diff时，首先比较type，然后是key，所以同级同类型元素，key值必须得 唯一 */}
//       {list.map((item) => (
//         <li key={item}>{item}</li>
//       ))}
//     </ul>
//     <img src={logo} className={styles.logo} alt=""></img>
//     {/*  style={{ width: "50px", height: "50px" }} */}
//   </div>
// );

// ReactDOM.render(jsx, document.getElementById("root"));
ReactDOM.render(<App />, document.getElementById("root"));
// store.subscribe(() => {
//   console.log("数据发生变化");
//   ReactDOM.render(<App />, document.getElementById("root"));
//   // this.forceUpdate();
// });

serviceWorker.unregister();

// 基本使用  表达式用{}包裹
// 函数
// JSX对象
// 条件语句
// 数组
// 属性
// 模块化
