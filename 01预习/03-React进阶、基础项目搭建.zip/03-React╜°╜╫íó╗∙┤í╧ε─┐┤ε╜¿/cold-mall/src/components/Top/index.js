import React, { Component } from "react";
import styles from "./index.module.scss";

export default class Top extends Component {
  render() {
    return (
      <div>
        <h3> Top </h3>
      </div>
    );
  }
}
