import React, { Component } from "react";
import styles from "./index.module.scss";

const menu = [
  {
    title: "首页",
    icon: "shouye",
    link: "/",
  },
  {
    title: "购物车",
    icon: "gouwuche",
    link: "/cart",
  },
  {
    title: "订单列表",
    icon: "dingdanliebiao",
    link: "/orderlist",
  },
  {
    title: "用户中心",
    icon: "yonghu",
    link: "/user",
  },
];

export default class BottomNav extends Component {
  render() {
    const { activeNum, setActiveNum } = this.props;
    return (
      <div className={styles.main}>
        {menu.map((item, index) => (
          <MenuItem
            key={index}
            {...item}
            active={activeNum === index}
            onClick={() => setActiveNum(index)}
          ></MenuItem>
        ))}
      </div>
    );
  }
}

function MenuItem({ title, icon, active, onClick }) {
  console.log(title, icon);
  return (
    <div
      className={(active ? styles.selected + " " : "") + styles.menuItem}
      onClick={onClick}
    >
      <span
        style={{ fontSize: 22 + "px" }}
        className={"iconfont icon-" + icon}
      ></span>
      <span className={styles.title}>{title}</span>
    </div>
  );
}
