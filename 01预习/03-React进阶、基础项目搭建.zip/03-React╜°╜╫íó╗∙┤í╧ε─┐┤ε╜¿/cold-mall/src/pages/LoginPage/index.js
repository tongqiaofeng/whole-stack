import React, { Component } from "react";
import styles from "./index.module.scss";

export default class LoginPage extends Component {
  render() {
    return (
      <div>
        <h3> LoginPage </h3>
      </div>
    );
  }
}
