import React, { Component } from "react";
import styles from "./index.module.scss";

export default class OrderListPage extends Component {
  render() {
    return (
      <div>
        <h3> OrderListPage </h3>
      </div>
    );
  }
}
