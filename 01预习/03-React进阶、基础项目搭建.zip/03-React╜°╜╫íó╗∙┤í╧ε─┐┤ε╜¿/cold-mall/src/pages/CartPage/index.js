import React, { Component } from "react";
import "./index.module.scss";

export default class CartPage extends Component {
  render() {
    return (
      <div>
        <h3> CartPage </h3>
      </div>
    );
  }
}
