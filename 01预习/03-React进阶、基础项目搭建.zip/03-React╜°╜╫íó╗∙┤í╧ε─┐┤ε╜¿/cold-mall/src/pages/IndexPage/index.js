import React, { Component } from "react";
// import styles from "./index.module.scss";

export default class IndexPage extends Component {
  render() {
    return (
      <div>
        <h3> IndexPage </h3>
      </div>
    );
  }
}
