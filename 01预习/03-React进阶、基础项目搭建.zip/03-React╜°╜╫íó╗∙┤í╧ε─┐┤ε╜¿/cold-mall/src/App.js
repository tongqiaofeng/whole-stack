import React, { useState } from "react";
import BottomNav from "./components/BottomNav";
import IndexPage from "./pages/IndexPage";
import CartPage from "./pages/CartPage";
import OrderListPage from "./pages/OrderListPage";
import UserPage from "./pages/UserPage";

function App() {
  const [activeNum, setActiveNum] = useState(0);

  return (
    <div className="App">
      {activeNum === 0 && <IndexPage></IndexPage>}
      {activeNum === 1 && <CartPage></CartPage>}
      {activeNum === 2 && <OrderListPage></OrderListPage>}
      {activeNum === 3 && <UserPage></UserPage>}
      <BottomNav activeNum={activeNum} setActiveNum={setActiveNum}></BottomNav>
    </div>
  );
}

export default App;
